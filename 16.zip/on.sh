#!/system/bin/sh

su -c iptables -F
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F
iptables -I INPUT -p tcp --dport 81 -j REJECT
iptables -I INPUT -p tcp --dport 8081 -j REJECT
iptables -I INPUT -p tcp --dport 18082 -j REJECT
iptables -I INPUT -p tcp --dport 3014 -j REJECT
iptables -I INPUT -p tcp --dport 1113 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 20374 -j REJECT
iptables -I OUTPUT -p tcp --dport 20374 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT
iptables -I OUTPUT -p tcp --dport 18082 -j REJECT
iptables -I OUTPUT -p tcp --dport 3014 -j REJECT
iptables -I OUTPUT -p tcp --dport 1113 -j REJECT
iptables -I OUTPUT -p tcp --dport 11443 -j REJECT
iptables -I OUTPUT -p udp --dport 81 -j REJECT
iptables -I INPUT -p udp --dport 8011 -j REJECT
iptables -I OUTPUT -p udp --dport 8011 -j REJECT
iptables -I OUTPUT -p udp --dport 111 -j REJECT
iptables -I OUTPUT -p udp --dport 11038 -j REJECT
iptables -I OUTPUT -p udp --dport 8011 -j REJECT
iptables -I OUTPUT -p udp --dport 20001 -j REJECT
iptables -I INPUT -p udp --dport 20001 -j REJECT
iptables -I INPUT -p tcp --dport 8082 -j REJECT
iptables -I INPUT -p tcp --dport 8087 -j REJECT
iptables -I INPUT -p tcp --dport 8288 -j REJECT
iptables -I INPUT -p tcp --dport 18082 -j REJECT
iptables -I INPUT -p tcp --dport 3014 -j REJECT
iptables -I INPUT -p tcp --dport 1113 -j REJECT
iptables -I INPUT -p tcp --dport 11443 -j REJECT
iptables -I INPUT -p tcp --dport 20374 -j REJECT
iptables -I OUTPUT -p tcp --dport 20374 -j REJECT
iptables -I OUTPUT -p tcp --dport 8082 -j REJECT
iptables -I OUTPUT -p tcp --dport 8087 -j REJECT
iptables -I OUTPUT -p tcp --dport 8288 -j REJECT
iptables -I OUTPUT -p tcp --dport 18082 -j REJECT
iptables -I OUTPUT -p tcp --dport 3014 -j REJECT
iptables -I OUTPUT -p tcp --dport 1113 -j REJECT
iptables -I INPUT -p udp --dport 23216 -j REJECT
iptables -I OUTPUT -p udp --dport 23216 -j REJECT
iptables -I INPUT -p udp --dport 20001 -j REJECT
iptables -I OUTPUT -p udp --dport 20001 -j REJECT
iptables -I INPUT -p udp --dport 15695 -j REJECT
iptables -I OUTPUT -p udp --dport 15695 -j REJECT
iptables -I INPUT -p udp --dport 10014 -j REJECT
iptables -I OUTPUT -p udp --dport 10014 -j REJECT
iptables -I INPUT -p udp --dport 10236 -j REJECT
iptables -I OUTPUT -p udp --dport 10236 -j REJECT
iptables -I INPUT -p udp --dport 25804 -j REJECT
iptables -I OUTPUT -p udp --dport 25804 -j REJECT
iptables -I INPUT -p udp --dport 12284 -j REJECT
iptables -I OUTPUT -p udp --dport 12284 -j REJECT
iptables -I INPUT -p udp --dport 9033 -j REJECT
iptables -I OUTPUT -p udp --dport 9033 -j REJECT
iptables -I INPUT -p udp --dport 9032 -j REJECT
iptables -I OUTPUT -p udp --dport 9032 -j REJECT
iptables -I INPUT -p tcp --dport 17499 -j REJECT
iptables -I OUTPUT -p tcp --dport 17499 -j REJECT
iptables -I INPUT -p udp --dport 16999 -j REJECT
iptables -I OUTPUT -p udp --dport 16999 -j REJECT
iptables -I INPUT -p tcp --dport 18499 -j REJECT
iptables -I OUTPUT -p tcp --dport 18499 -j REJECT
