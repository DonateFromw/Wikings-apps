rm -rf /data/data/com.rekoo.pubgm/files &> /dev/null
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord &> /dev/null
echo "@WikingsMod" > /data/data/com.rekoo.pubgm/files
echo "@WikingsMod" > /data/data/com.rekoo.pubgm/app_crashrecord
chmod 000 /data/data/com.rekoo.pubgm/files
chmod 000 /data/data/com.rekoo.pubgm/app_crashrecord
rm -rf /data/data/com.rekoo.pubgm/files &> /dev/null
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord &> /dev/null
echo "CrashFix..." > /data/data/com.rekoo.pubgm/files
echo "JOIN TELEGRAM @WikingsMod" > /data/data/com.rekoo.pubgm/app_crashrecord
chmod 000 /data/data/com.rekoo.pubgm/files
chmod 000 /data/data/com.rekoo.pubgm/app_crashrecord
echo "Crash Fix Done" 

rm -rf /com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*

rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*

chmod 555 /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

echo "DONE"
echo " JOIN @WikingsMod "